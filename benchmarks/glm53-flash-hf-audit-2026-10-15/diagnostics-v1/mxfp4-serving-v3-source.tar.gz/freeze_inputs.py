"""Freeze CT-tokenizer prompts and drafter compatibility before GPU work."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT.parent / "full-c16admissionv1-src"))
import full_model_control as c


def main():
    plan = json.loads((ROOT / "plan.json").read_bytes())
    assert len(plan["cases"]) == 2
    previous = json.loads((ROOT.parent / "dflash-c1-v1/prepared.json").read_bytes())
    mounts = {
        target: source for source, target, _ in previous["launches"]["candidate"][0]["mounts"]
    }
    target = Path(mounts["/model"])
    draft = Path(mounts["/draft"])
    tc = json.loads((target / "config.json").read_bytes())["text_config"]
    dc = json.loads((draft / "config.json").read_bytes())
    checks = {
        "hidden_size": tc["hidden_size"] == dc["hidden_size"],
        "vocab_size": tc["vocab_size"] == dc["vocab_size"],
        "num_layers": tc["num_hidden_layers"] == dc["num_target_layers"],
        "target_layers": dc["dflash_config"]["target_layer_ids"] == [5, 14, 24, 33, 42],
        "block_size": dc["dflash_config"]["block_size"] == 8,
    }
    assert all(checks.values())
    script = """import json
from transformers import AutoTokenizer
from pathlib import Path
tokenizer=AutoTokenizer.from_pretrained('/model',local_files_only=True)
results=[]
for row in json.loads(Path('/trial/prompts.json').read_bytes()):
 ids=tokenizer.apply_chat_template([{'role':'user','content':row['text']}],tokenize=True,add_generation_prompt=True,enable_thinking=False)
 if not isinstance(ids,list): ids=ids['input_ids']
 assert all(isinstance(x,int) for x in ids) and 0<len(ids)<2048
 results.append(dict(name=row['name'],output_tokens=row['output_tokens'],kind=row['kind'],batch=1,prompt_tokens=len(ids),prompts=[ids]))
print(json.dumps(results))
"""
    argv = [
        "docker",
        "run",
        "--rm",
        "--network",
        "none",
        "--cpus",
        "2",
        "--memory",
        "3g",
        "-e",
        "CUDA_VISIBLE_DEVICES=",
        "-e",
        "NVIDIA_VISIBLE_DEVICES=void",
        "-e",
        "HF_HUB_OFFLINE=1",
        "-e",
        "TRANSFORMERS_OFFLINE=1",
        "-v",
        f"{target}:/model:ro",
        "-v",
        f"{ROOT}:/trial:ro",
        "--entrypoint",
        "/usr/bin/python3",
        c.IMAGE,
        "-c",
        script,
    ]
    proc = subprocess.run(argv, capture_output=True, text=True, timeout=240, check=False)
    (ROOT / "tokenize.log").write_text(proc.stderr)
    assert proc.returncode == 0, proc.stderr[-2000:]
    cases = json.loads(proc.stdout.strip().splitlines()[-1])
    plan["cases"].extend(cases)
    c.write(ROOT / "plan.json", plan)
    files = {}
    for prefix, folder in [("target", target), ("draft", draft)]:
        for name in [
            "config.json",
            "tokenizer.json",
            "tokenizer_config.json",
            "chat_template.jinja",
            "README.md",
        ]:
            p = folder / name
            if p.exists():
                files[f"{prefix}/{name}"] = hashlib.sha256(p.read_bytes()).hexdigest()
    c.write(
        ROOT / "drafter-compatibility.json",
        {
            "status": "structural_checks_passed",
            "checks": checks,
            "target": str(target),
            "draft": str(draft),
            "source_sha256": files,
            "target_provenance": "Existing AutoRound CT MXFP4 checkpoint with MxWave lossless runtime; no new MxWave quantization weights.",
            "scope": "Structural compatibility and prior shared target head/embedding evidence; not a measured acceptance or quality result for the new prompts.",
            "prior_dflash_c1_v1": {
                "current": {"accepted": 899, "drafted": 910},
                "ct_stock": {"accepted": 899, "drafted": 910},
                "candidate": {"accepted": 899, "drafted": 910},
            },
        },
    )
    print(
        json.dumps(
            {
                "status": "frozen",
                "cases": [{k: v for k, v in x.items() if k != "prompts"} for x in plan["cases"]],
            }
        )
    )


if __name__ == "__main__":
    main()

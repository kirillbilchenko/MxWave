"""Exercise restoration without Docker, networking, or GPUs."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import json
import time
import fcntl
import contextlib

source=Path('/private/tmp/mxwave-mxfp4-serving-v3/control.py').read_text()
body=source[source.index('def save('):source.index('if __name__ == "__main__":')]

def exercise(bad_identity=False):
    with TemporaryDirectory() as tmp:
        root=Path(tmp); ids=[{'id':'original0'},{'id':'original1'}]
        launches={f'{a}{i}':[{'rank':r,'name':f'{a}{i}-r{r}'} for r in (0,1)] for i in (1,2,3) for a in 'ab'}
        prepared={'live':ids,'originals':ids,'launches':launches}
        (root/'prepared.json').write_text(json.dumps(prepared))
        state={'phase':'measuring_b1','service_paused':True}
        (root/'controller.json').write_text(json.dumps(state))
        running={x['name']:True for entries in launches.values() for x in entries}
        running.update(original0=False,original1=False);calls=[]
        def inspect(rank,name):
            return {'identity':{'id':name+('changed' if bad_identity and name=='original1' else '')},'State':{'Running':running[name]}}
        def run(rank,cmd,**kwargs):
            calls.append((rank,cmd))
            if cmd[1]=='ps':
                name=cmd[-1].removeprefix('name=^/').removesuffix('$')
                return name if running[name] else ''
            if cmd[1]=='stop':running[cmd[-1]]=False
            if cmd[1]=='start':running[cmd[-1]]=True
            return ''
        c=SimpleNamespace(inspect=inspect,identity=lambda x:x['identity'],run=run,ORIGINAL_IDS=('original0','original1'),health=lambda _:all(running[x] for x in ('original0','original1')),write=lambda p,v:p.write_text(json.dumps(v)))
        def request(*args,**kwargs):return 'request'
        def urlopen(*args,**kwargs):
            return contextlib.nullcontext(__import__('io').StringIO(json.dumps({'data':[{'id':'glm-5.3-flash','max_model_len':500000}]})))
        # Replace secret read with a local dummy only in this isolated test copy.
        test_body=body.replace('pathlib.Path("/home/kirya/local-spark/runtime/secrets/llm_api_key")','pathlib.Path(ROOT / "dummy-key")')
        (root/'dummy-key').write_text('local-test-only')
        env={'__name__':'restore_test','ROOT':root,'STATE':root/'controller.json','TERMINAL':('complete_restored','failed_restored','preparation_failed'),'c':c,'json':json,'time':time,'fcntl':fcntl,'pathlib':__import__('pathlib'),'urllib':SimpleNamespace(request=SimpleNamespace(Request=request,urlopen=urlopen)),'serving':SimpleNamespace(stop_client=lambda _:None)}
        exec(test_body,env)
        if bad_identity:
            try:env['restore']()
            except AssertionError:pass
            else:raise AssertionError('Modified original identity was accepted')
            assert not any(cmd[1]=='start' and cmd[-1]=='original1' for _,cmd in calls)
        else:
            env['restore']()
            assert json.loads((root/'controller.json').read_bytes())['phase']=='complete_restored'
            assert [rank for rank,cmd in calls if cmd[1]=='start']==[1,0]
            assert all(running[x] for x in ('original0','original1'))
            assert all(not running[x['name']] for entries in launches.values() for x in entries)
            before=len(calls);env['restore']();assert len(calls)==before
exercise();exercise(True)
print('Restoration checks passed: originals restarted rank1/rank0, experimental containers stopped, terminal restoration idempotent, changed original configuration rejected.')

"""Measure ordinary authenticated API streams under one immutable paired protocol."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import pathlib
import statistics
import threading
import time
import urllib.request

ROOT = pathlib.Path(__file__).parent
BASE = "http://127.0.0.1:8012"


def write(path, value):
    temporary = path.with_suffix(".incomplete")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def headers():
    key = pathlib.Path("/home/kirya/local-spark/runtime/secrets/llm_api_key").read_text().strip()
    assert key and "\n" not in key
    return {"Content-Type": "application/json", "Authorization": "Bearer " + key}


def request(path, payload=None, timeout=240):
    query = urllib.request.Request(
        BASE + path,
        headers=headers(),
        data=None if payload is None else json.dumps(payload).encode(),
    )
    with urllib.request.urlopen(query, timeout=timeout) as response:
        return response.read()


def stream(prompt, tokens, barrier=None):
    body = {
        "model": "glm-5.3-flash",
        "prompt": prompt,
        "min_tokens": tokens,
        "max_tokens": tokens,
        "temperature": 0,
        "seed": 42,
        "ignore_eos": True,
        "stream": True,
        "stream_options": {"include_usage": True},
        "return_token_ids": True,
    }
    query = urllib.request.Request(
        BASE + "/v1/completions", headers=headers(), data=json.dumps(body).encode()
    )
    if barrier is not None:
        barrier.wait(timeout=30)
    start = time.perf_counter_ns()
    epoch = time.time_ns()
    arrivals = []
    ids = []
    usage = None
    finish = None
    with urllib.request.urlopen(query, timeout=300) as response:
        for line in response:
            if not line.startswith(b"data: ") or line.strip() == b"data: [DONE]":
                continue
            event = json.loads(line[6:])
            now = time.perf_counter_ns()
            if "error" in event:
                raise RuntimeError(str(event["error"]))
            for choice in event.get("choices", []):
                delta = choice.get("token_ids") or []
                if delta:
                    ids.extend(delta)
                    arrivals.append({"seconds": (now - start) / 1e9, "tokens": len(delta)})
                finish = choice.get("finish_reason") or finish
            usage = event.get("usage") or usage
    end = time.perf_counter_ns()
    assert len(ids) == tokens and arrivals and usage is not None, (len(ids), usage)
    assert usage["completion_tokens"] == tokens and usage["prompt_tokens"] == len(prompt)
    ttft = arrivals[0]["seconds"]
    latency = (end - start) / 1e9
    return {
        "start_epoch_ns": epoch,
        "start_ns": start,
        "end_ns": end,
        "latency_seconds": latency,
        "ttft_seconds": ttft,
        "tpot_seconds": (arrivals[-1]["seconds"] - ttft) / (tokens - 1),
        "token_ids": ids,
        "arrivals": arrivals,
        "usage": usage,
        "finish_reason": finish,
    }


def group(case, tokens):
    barrier = threading.Barrier(case["batch"])
    start = time.perf_counter_ns()
    with concurrent.futures.ThreadPoolExecutor(max_workers=case["batch"]) as pool:
        jobs = [pool.submit(stream, p, tokens, barrier) for p in case["prompts"]]
        results = [f.result() for f in jobs]
    duration = (time.perf_counter_ns() - start) / 1e9
    return {
        "case": case["name"],
        "batch": case["batch"],
        "prompt_tokens": case["prompt_tokens"],
        "requests": results,
        "wall_seconds": duration,
        "output_tokens": tokens * case["batch"],
        "output_tokens_per_second": tokens * case["batch"] / duration,
    }


def percentile(values, p):
    values = sorted(values)
    at = (len(values) - 1) * p
    lo = int(at)
    hi = min(lo + 1, len(values) - 1)
    return values[lo] + (values[hi] - values[lo]) * (at - lo)


def summarize(rows):
    result = []
    for case in sorted({r["case"] for r in rows}):
        groups = [r for r in rows if r["case"] == case]
        requests = [x for g in groups for x in g["requests"]]
        result.append(
            {
                "case": case,
                "prompt_tokens": groups[0]["prompt_tokens"],
                "output_tokens": groups[0]["output_tokens"],
                "trials": len(groups),
                "median_output_tokens_per_second": statistics.median(
                    g["output_tokens_per_second"] for g in groups
                ),
                "mean_ttft_seconds": statistics.mean(x["ttft_seconds"] for x in requests),
                "mean_tpot_seconds": statistics.mean(x["tpot_seconds"] for x in requests),
                "mean_request_latency_seconds": statistics.mean(
                    x["latency_seconds"] for x in requests
                ),
            }
        )
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", required=True)
    args = parser.parse_args()
    plan = json.loads((ROOT / "plan.json").read_bytes())
    path = ROOT / (args.arm + "-measurement.json")
    assert not path.exists()
    state = {
        "status": "running",
        "arm": args.arm,
        "mode": plan["modes"][args.arm],
        "started_epoch": time.time(),
        "warmups": [],
        "trials": [],
        "sanity": [],
        "plan_sha256": hashlib.sha256((ROOT / "plan.json").read_bytes()).hexdigest(),
        "client_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        "endpoint": BASE,
        "full_model_KL_qualified": False,
    }
    write(path, state)
    try:
        state["models"] = json.loads(request("/v1/models"))
        state["metrics_before"] = request("/metrics").decode()
        for prompt, want in [
            ("Reply with only the digit: what is 2 + 2?", "4"),
            ("Translate hello into French. Reply with only the translation.", "bonjour"),
        ]:
            reply = json.loads(
                request(
                    "/v1/chat/completions",
                    {
                        "model": "glm-5.3-flash",
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0,
                        "seed": 42,
                        "max_tokens": 32,
                        "chat_template_kwargs": {"enable_thinking": False},
                    },
                )
            )
            text = reply["choices"][0]["message"].get("content") or ""
            state["sanity"].append(
                {
                    "prompt": prompt,
                    "expected": want,
                    "response": reply,
                    "passed": text.strip().strip(".!").strip().casefold() == want,
                }
            )
        assert all(r["passed"] for r in state["sanity"]), state["sanity"]
        for index, case in enumerate(plan["cases"]):
            state.update(phase="warmup", case_index=index)
            write(path, state)
            state["warmups"].append(group(case, case["output_tokens"]))
        for trial in range(plan["trials"]):
            order = list(range(len(plan["cases"])))
            if (trial + plan["arms"].index(args.arm)) % 2:
                order.reverse()
            for index in order:
                state.update(phase="timing", trial=trial, case_index=index)
                write(path, state)
                before = request("/metrics").decode()
                row = group(plan["cases"][index], plan["cases"][index]["output_tokens"])
                row["trial"] = trial
                row["metrics_before"] = before
                row["metrics_after"] = request("/metrics").decode()
                state["trials"].append(row)
                write(path, state)
        state["metrics_after"] = request("/metrics").decode()
        state["summary"] = summarize(state["trials"])
        state["timing_finished_epoch"] = time.time()
        write(path, state)
        # Keep profiling out of every timing group; annotate only this last request.
        if args.arm in plan["profile_arms"]:
            request("/start_profile", {})
            try:
                state["profile_request"] = group(plan["cases"][2], plan["profile_output_tokens"])
            finally:
                request("/stop_profile", {})
        state.update(status="complete", phase="complete", finished_epoch=time.time())
        write(path, state)
        print(json.dumps(state["summary"]))
    except BaseException as exc:
        state.update(status="failed", error=repr(exc), finished_epoch=time.time())
        write(path, state)
        raise


if __name__ == "__main__":
    main()

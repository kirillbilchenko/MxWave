"""Start the authenticated trial using unchanged model adapters and an additive startup hook."""
from __future__ import annotations
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile


def main():
    import hashlib
    import glm_levers
    revision=json.loads(pathlib.Path('/trial/revision.json').read_bytes())
    assert hashlib.sha256(pathlib.Path(glm_levers.__file__).read_bytes()).hexdigest()==revision['glm_levers_source_sha256']
    assert glm_levers.DRAFT_FP8_KV
    source=pathlib.Path(os.environ['MXWAVE_TRIAL_FROZEN_CODE'])/'engine_plugin'
    with tempfile.TemporaryDirectory(prefix='mxwave-serving-entry-')as tmp:
        package=pathlib.Path(tmp)/'package';shutil.copytree(source,package)
        p=package/'pyproject.toml';s=p.read_text()
        anchor='[tool.setuptools]'
        assert s.count(anchor)==1
        p.write_text(s.replace(anchor,'mxwave_serving_trial = "trial_plugin:install"\n\n'+anchor))
        subprocess.run(['uv','pip','install','--python','/usr/bin/python3',
            '--break-system-packages','--no-deps','--no-build-isolation',str(package)],check=True)
    if os.environ.get('MXWAVE_VALIDATE_ONLY')=='1':
        from vllm import platforms
        from vllm.platforms.cpu import CpuPlatform
        platforms.current_platform=CpuPlatform()
        from vllm.entrypoints.cli.serve import cmd_init
        from vllm.plugins import load_general_plugins
        from vllm.utils.argparse_utils import FlexibleArgumentParser
        load_general_plugins()
        parser=FlexibleArgumentParser();sub=parser.add_subparsers(dest='subparser')
        commands=cmd_init()
        for command in commands:command.subparser_init(sub)
        args=parser.parse_args(sys.argv[1:])
        next(c for c in commands if c.name==args.subparser).validate(args)
        assert args.max_model_len==8192 and args.max_num_batched_tokens==2048
        assert args.max_num_seqs==16 and args.speculative_config['method']=='dflash'
        import torch
        import types
        import glm_levers
        from vllm.model_executor.models.qwen3_dflash import DFlashQwen3Model
        assert glm_levers.DRAFT_FP8_KV
        assert getattr(DFlashQwen3Model._build_context_kv_buffers,'_glm_lv',False)
        # Reproduce the failed buffer contract without loading a model or using GPU.
        fixture=types.SimpleNamespace(hidden_norm=types.SimpleNamespace(weight=torch.ones(128,dtype=torch.bfloat16)))
        attention=[];expected=[]
        for offset in (0,1):
            weight=((torch.arange(384*128).reshape(384,128)+offset)%15-7).to(torch.float8_e4m3fn)
            scales=torch.tensor([[.25],[.5],[2.]])
            attention.append(types.SimpleNamespace(q_size=128,
                qkv_proj=types.SimpleNamespace(weight=weight,weight_scale_inv=scales,bias=None),
                k_norm=types.SimpleNamespace(weight=torch.ones(16,dtype=torch.bfloat16))))
            expected.append((weight[128:].float()*scales[1:].repeat_interleave(128,0)).to(torch.bfloat16))
        DFlashQwen3Model._build_context_kv_buffers(fixture,attention,False)
        assert fixture._fused_kv_weight.dtype==torch.bfloat16
        assert torch.equal(fixture._fused_kv_weight,torch.cat(expected))
        assert torch.nn.functional.linear(torch.ones(2,128,dtype=torch.bfloat16),fixture._fused_kv_weight).dtype==torch.bfloat16
        import trial_worker
        assert hasattr(trial_worker.TrialWorker,'mxwave_prepare_dispatch_startup')
        print(json.dumps(dict(status='validated',arm=os.environ['MXWAVE_TRIAL_ARM'],
            speculation='dflash',max_model_len=args.max_model_len)))
        return
    secret=pathlib.Path('/run/secrets/llm_api_key').read_text().strip()
    assert secret and '\n'not in secret
    os.environ['VLLM_API_KEY']=secret
    assert os.environ['VLLM_SERVER_DEV_MODE']=='0'
    os.execv('/usr/bin/python3',['/usr/bin/python3','-c',
        'from vllm.entrypoints.cli.main import main; main()',*sys.argv[1:]])


if __name__=='__main__':main()

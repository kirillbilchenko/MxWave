"""Retain the completed comparison without changing frozen experiment payloads."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT.parent / "full-c16admissionv1-src"))
import full_model_control as c


def main():
    state = json.loads((ROOT / "controller.json").read_bytes())
    assert state["phase"] in ("complete_restored", "failed_restored") and not state["service_paused"]
    plan = json.loads((ROOT / "plan.json").read_bytes())
    for block in plan["arms"]:
        directory = ROOT / f"{block}-r1"
        directory.mkdir(exist_ok=True)
        script = 'import json,pathlib,sys;p=pathlib.Path(sys.argv[1]);print(json.dumps([x.name for x in p.iterdir() if x.is_file() and (x.suffix in (".json",".gz",".txt",".safetensors"))]))'
        names = json.loads(c.run(1, ["python3", "-S", "-c", script, str(directory)]))
        for name in names:
            assert Path(name).name == name
            subprocess.run(
                [
                    "scp",
                    "-i",
                    "/home/kirya/.ssh/id_glm_cluster",
                    f"kirya@192.168.192.2:{directory / name}",
                    str(directory / name),
                ],
                check=True,
                timeout=120,
            )
    for block in plan["arms"]:
        for rank in (0, 1):
            path = ROOT / f"{block}-r{rank}" / f"trial-startup-r{rank}.json"
            if state["phase"] == "complete_restored":
                assert json.loads(path.read_bytes())["status"] == "complete"
    identities = [c.identity(c.inspect(rank, c.ORIGINAL_IDS[rank])) for rank in (0, 1)]
    assert identities == json.loads((ROOT / "prepared.json").read_bytes())["originals"]
    assert c.health(8000)
    c.write(
        ROOT / "final-service-review.json",
        {
            "status": "verified",
            "originals_running": all(
                c.inspect(r, c.ORIGINAL_IDS[r])["State"]["Running"] for r in (0, 1)
            ),
            "identities": identities,
            "health_200": True,
            "controller_restoration": state["restoration"],
        },
    )
    files = []
    for f in sorted(ROOT.rglob("*")):
        if not f.is_file() or "__pycache__" in f.parts or f.suffix in (".lock", ".incomplete"):
            continue
        if f.name in ("evidence-v1.tar.gz", "evidence-manifest.json", "archive-receipt.json",
                      "postprocess.log", "postprocess-complete.json", "queue.json",
                      "queue.log", "finalize-queue.log"):
            continue
        files.append(
            {
                "path": str(f.relative_to(ROOT)),
                "bytes": f.stat().st_size,
                "sha256": hashlib.sha256(f.read_bytes()).hexdigest(),
            }
        )
    c.write(ROOT / "evidence-manifest.json", {"schema": "mxwave-evidence-v1", "files": files})
    archive = ROOT / "evidence-v1.tar.gz"
    assert not archive.exists()
    with tarfile.open(archive, "w:gz", compresslevel=1) as tar:
        for entry in files:
            tar.add(ROOT / entry["path"], arcname=entry["path"], recursive=False)
        tar.add(ROOT / "evidence-manifest.json", arcname="evidence-manifest.json")
    receipt = {
        "status": "retained",
        "bytes": archive.stat().st_size,
        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "payloads": len(files),
    }
    c.write(ROOT / "archive-receipt.json", receipt)
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()

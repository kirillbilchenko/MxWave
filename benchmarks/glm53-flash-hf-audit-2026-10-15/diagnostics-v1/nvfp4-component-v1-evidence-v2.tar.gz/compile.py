import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/experiment/native');staged=root/'staged'
result={'started':time.time(),'libraries':{}}
for variant,compressed in [('raw',0),('direct5',1)]:
 output=root/('libnv_'+variant+'.so')
 argv=['nvcc','-std=c++17','--shared','-Xcompiler=-fPIC','-O3','-arch=sm_121','--use_fast_math','--expt-extended-lambda','--expt-relaxed-constexpr','-lineinfo','-Xptxas=-v',f'-DNV_COMPRESSED={compressed}',f'-DMARLIN_NAMESPACE_NAME=nv_{variant}',f'-I{staged}',f'-I{staged}/libtorch_stable/moe/marlin_moe_wna16','-I/usr/local/lib/python3.12/dist-packages/torch/include',str(staged/'host.cu'),'-o',str(output)]
 with (root/(variant+'-build.log')).open('w') as log:
  run=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=480)
 result['libraries'][variant]={'argv':argv,'exit_code':run.returncode}
 if run.returncode==0:result['libraries'][variant]['sha256']=hashlib.sha256(output.read_bytes()).hexdigest()
 (root/'build.json').write_text(json.dumps(result,indent=2)+'\n')
 if run.returncode:raise SystemExit(run.returncode)
result['finished']=time.time();(root/'build.json').write_text(json.dumps(result,indent=2)+'\n')

import json,struct,numpy as np
from pathlib import Path
root=Path('/model')
idx=json.loads((root/'model.safetensors.index.json').read_text())['weight_map']
headers={};records=[]
for rank in (0,1):
 for expert in [round(i*287/15) for i in range(16)]:
  for proj in ('gate_proj','up_proj','down_proj'):
   name=f'model.language_model.layers.23.mlp.experts.{expert}.{proj}.weight_scale'
   filename=idx[name]
   with (root/filename).open('rb') as f:
    if filename not in headers:
     length=struct.unpack('<Q',f.read(8))[0];headers[filename]=(length,json.loads(f.read(length)))
    length,h=headers[filename];v=h[name];start,end=v['data_offsets'];f.seek(8+length+start);a=np.frombuffer(f.read(end-start),np.uint8).reshape(v['shape'])
   a=a[:,rank*64:(rank+1)*64] if proj=='down_proj' else a[rank*1024:(rank+1)*1024]
   u=np.unique(a);records.append({'rank':rank,'expert':expert,'projection':proj,'minimum':int(u[0]),'maximum':int(u[-1]),'span':int(u[-1])-int(u[0])+1,'distinct':len(u),'consecutive':bool(np.all(np.diff(u)==1))})
result={'source':'selected layer23 TP2 source-scale bytes; positive normal E4M3, runtime mapping still requires verification','records':records,'fits_5bit_span':sum(r['span']<=32 for r in records),'parts':len(records)}
Path('/result/range-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['fits_5bit_span'],result['parts'])

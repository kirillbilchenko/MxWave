/*
 * Modified by Neural Magic
 * Copyright (C) Marlin.2024 Elias Frantar
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * Adapted from https://github.com/IST-DASLab/marlin
 */

#ifndef MARLIN_NAMESPACE_NAME
  #define MARLIN_NAMESPACE_NAME marlin_moe_wna16
#endif

#include "kernel.h"

#include <torch/csrc/stable/accelerator.h>
#include <torch/csrc/stable/library.h>
#include <torch/csrc/stable/ops.h>
#include <torch/csrc/stable/tensor.h>
#include <torch/headeronly/core/ScalarType.h>
#include <torch/headeronly/util/Exception.h>

#include "libtorch_stable/torch_utils.h"

#define STATIC_ASSERT_SCALAR_TYPE_VALID(scalar_t)               \
  static_assert(std::is_same<scalar_t, half>::value ||          \
                    std::is_same<scalar_t, nv_bfloat16>::value, \
                "only float16 and bfloat16 is supported");

namespace MARLIN_NAMESPACE_NAME {

__global__ void MarlinDefault(MARLIN_KERNEL_PARAMS){};

using MarlinFuncPtr = void (*)(MARLIN_KERNEL_PARAMS);

typedef struct {
  int thread_k;
  int thread_n;
  int num_threads;
} thread_config_t;

thread_config_t small_batch_thread_configs[] = {
    // Ordered by priority

    // thread_k, thread_n, num_threads
    {128, 128, 256},
    {64, 128, 128},
    {128, 64, 128}};

thread_config_t large_batch_thread_configs[] = {
    // Ordered by priority

    // thread_k, thread_n, num_threads
    {64, 256, 256},
    {64, 128, 128},
    {128, 64, 128}};

typedef struct {
  int blocks_per_sm;
  thread_config_t tb_cfg;
} exec_config_t;

int get_scales_cache_size(thread_config_t const& th_config, int prob_m,
                          int prob_n, int prob_k, int num_bits, int group_size,
                          int stages) {
  int tb_n = th_config.thread_n;
  int tb_k = th_config.thread_k;

  // Get max scale groups per thread-block
  int tb_groups;
  if (group_size == -1) {
    tb_groups = 1;
  } else {
    tb_groups = div_ceil(tb_k, group_size);
  }

  int tb_scales = tb_groups * tb_n * 2;
  return tb_scales * stages;
}

int get_kernel_cache_size(thread_config_t const& th_config, bool m_block_size_8,
                          int thread_m_blocks, int prob_m, int prob_n,
                          int prob_k, int num_bits, int group_size, int has_zp,
                          int is_zp_float, bool is_a_8bit, int stages) {
  int pack_factor = 32 / num_bits;

  // Get B size
  int tb_k = th_config.thread_k;
  int tb_n = th_config.thread_n;
  int tb_m = thread_m_blocks * 16;

  // shm size for block_sorted_ids/rd_block_sorted_ids/block_topk_weights
  // both of them requires tb_m * 4 bytes (tb_m * int32 or tb_m * float32)
  int sh_block_meta_size = tb_m * 16;
  int sh_a_size = stages * (tb_m * tb_k) * (is_a_8bit ? 1 : 2);
  int sh_b_size = stages * (tb_k * tb_n / pack_factor) * 4;
  int sh_red_size = tb_m * (tb_n + 8) * 2;
  int sh_bias_size = tb_n * 2;
  int tmp_size =
      (sh_b_size > sh_red_size ? sh_red_size : sh_b_size) + sh_bias_size;
  tmp_size = max(max(sh_b_size, sh_red_size), tmp_size);

  int sh_s_size = get_scales_cache_size(th_config, prob_m, prob_n, prob_k,
                                        num_bits, group_size, stages);
  int sh_zp_size = 0;
  if (has_zp) {
    if (is_zp_float)
      sh_zp_size = sh_s_size;
    else if (num_bits == 4)
      sh_zp_size = sh_s_size / 4;
    else if (num_bits == 8)
      sh_zp_size = sh_s_size / 2;
  }

  int total_size =
      tmp_size + sh_a_size + sh_s_size + sh_zp_size + sh_block_meta_size;

  return total_size;
}

bool is_valid_config(thread_config_t const& th_config, bool m_block_size_8,
                     int thread_m_blocks, int prob_m, int prob_n, int prob_k,
                     int num_bits, int group_size, int has_zp, int is_zp_float,
                     bool is_a_8bit, int stages, int max_shared_mem) {
  // Sanity
  if (th_config.thread_k == -1 || th_config.thread_n == -1 ||
      th_config.num_threads == -1) {
    return false;
  }

  // Verify K/N are divisible by thread K/N
  if (prob_k % th_config.thread_k != 0 || prob_n % th_config.thread_n != 0) {
    return false;
  }

  // Verify min for thread K/N
  if (th_config.thread_n < min_thread_n || th_config.thread_k < min_thread_k) {
    return false;
  }

  // num_threads must be at least 128 (= 4 warps)
  if (th_config.num_threads < 128) {
    return false;
  }

  // Check that pipeline fits into cache
  int cache_size = get_kernel_cache_size(
      th_config, m_block_size_8, thread_m_blocks, prob_m, prob_n, prob_k,
      num_bits, group_size, has_zp, is_zp_float, is_a_8bit, stages);
  return cache_size <= max_shared_mem;
}

MarlinFuncPtr get_marlin_kernel(const vllm::ScalarType a_type,
                                const vllm::ScalarType b_type,
                                const vllm::ScalarType c_type,
                                const vllm::ScalarType s_type,
                                int thread_m_blocks, int thread_n_blocks,
                                int thread_k_blocks, bool m_block_size_8,
                                bool has_zp, int group_blocks, int threads,
                                bool is_zp_float, int stages) {
  int num_bits = b_type.size_bits();
  auto kernel = MarlinDefault;

#include "kernel_selector.h"

  return kernel;
}

exec_config_t determine_exec_config(
    const vllm::ScalarType& a_type, const vllm::ScalarType& b_type,
    const vllm::ScalarType& c_type, const vllm::ScalarType& s_type, int prob_m,
    int prob_n, int prob_k, int num_experts, int top_k, int thread_m_blocks,
    bool m_block_size_8, int num_bits, int group_size, bool has_zp,
    bool is_zp_float, bool is_a_8bit, int stages, int max_shared_mem, int sms) {
  exec_config_t exec_cfg = exec_config_t{1, thread_config_t{-1, -1, -1}};
  thread_config_t* thread_configs = thread_m_blocks > 1
                                        ? large_batch_thread_configs
                                        : small_batch_thread_configs;
  int thread_configs_size =
      thread_m_blocks > 1
          ? sizeof(large_batch_thread_configs) / sizeof(thread_config_t)
          : sizeof(small_batch_thread_configs) / sizeof(thread_config_t);

  int count = 0;
  constexpr int device_max_reg_size = 255 * 1024;
  for (int i = 0; i < thread_configs_size; i++) {
    thread_config_t th_config = thread_configs[i];

    if (!is_valid_config(th_config, m_block_size_8, thread_m_blocks, prob_m,
                         prob_n, prob_k, num_bits, group_size, has_zp,
                         is_zp_float, is_a_8bit, stages,
                         max_shared_mem - 512)) {
      continue;
    }

    int cache_size = get_kernel_cache_size(
        th_config, m_block_size_8, thread_m_blocks, prob_m, prob_n, prob_k,
        num_bits, group_size, has_zp, is_zp_float, is_a_8bit, stages);

    int group_blocks = group_size == -1 ? -1 : (group_size / 16);

    auto kernel = get_marlin_kernel(
        a_type, b_type, c_type, s_type, thread_m_blocks,
        th_config.thread_n / 16, th_config.thread_k / 16, m_block_size_8,
        has_zp, group_blocks, th_config.num_threads, is_zp_float, stages);

    if (kernel == MarlinDefault) continue;

    cudaFuncAttributes attr;
    cudaFuncGetAttributes(&attr, kernel);
    int reg_size = max(attr.numRegs, 1) * th_config.num_threads * 4;
    int allow_count = min(device_max_reg_size / reg_size,
                          max_shared_mem / (cache_size + 1536));
    if (thread_m_blocks == 1)
      allow_count = max(min(allow_count, 4), 1);
    else
      allow_count = max(min(allow_count, 2), 1);

    if (prob_n / th_config.thread_n * prob_m * top_k * 4 < sms * allow_count) {
      allow_count =
          max(prob_n / th_config.thread_n * prob_m * top_k * 4 / sms, 1);
    }

    if (allow_count > count) {
      count = allow_count;
      exec_cfg = {count, th_config};
    };
  }

  return exec_cfg;
}

void marlin_mm(const void* A, const void* B, void* C, void* C_tmp, void* b_bias,
               void* a_s, void* b_s, void* g_s, void* zp,
               void* sorted_token_ids, void* expert_ids,
               void* num_tokens_past_padded, void* topk_weights,
               int moe_block_size, int num_experts, int top_k,
               bool mul_topk_weights, int prob_m, int prob_n, int prob_k,
               void* workspace, vllm::ScalarType const& a_type,
               vllm::ScalarType const& b_type, vllm::ScalarType const& c_type,
               vllm::ScalarType const& s_type, bool has_bias, bool has_zp,
               int group_size, int dev, cudaStream_t stream, int thread_k,
               int thread_n, int sms, int blocks_per_sm, bool use_atomic_add,
               bool use_fp32_reduce, bool is_zp_float) {
  int thread_m_blocks = div_ceil(moe_block_size, 16);
  bool m_block_size_8 = moe_block_size == 8;
  bool is_a_8bit = a_type.size_bits() == 8;

  STD_TORCH_CHECK(prob_m > 0 && prob_n > 0 && prob_k > 0, "Invalid MNK = [",
                  prob_m, ", ", prob_n, ", ", prob_k, "]");

  int group_blocks;
  if (group_size == -1) {
    group_blocks = -1;
  } else {
    group_blocks = group_size / 16;
    STD_TORCH_CHECK(prob_k % group_blocks == 0, "prob_k = ", prob_k,
                    " is not divisible by group_blocks = ", group_blocks);
  }

  int num_bits = b_type.size_bits();
  const int4* A_ptr = (const int4*)A;
  const int4* B_ptr = (const int4*)B;
  int4* C_ptr = (int4*)C;
  int4* C_tmp_ptr = (int4*)C_tmp;
  const int4* bias_ptr = (const int4*)b_bias;
  const float* a_s_ptr = (const float*)a_s;
  const int4* b_s_ptr = (const int4*)b_s;
  const float* g_s_ptr = (const float*)g_s;
  const int4* zp_ptr = (const int4*)zp;
  const int32_t* sorted_token_ids_ptr = (const int32_t*)sorted_token_ids;
  const int32_t* expert_ids_ptr = (const int32_t*)expert_ids;
  const int32_t* num_tokens_past_padded_ptr =
      (const int32_t*)num_tokens_past_padded;
  const float* topk_weights_ptr = (const float*)topk_weights;
  int* locks = (int*)workspace;

  int max_shared_mem = 0;
  cudaDeviceGetAttribute(&max_shared_mem,
                         cudaDevAttrMaxSharedMemoryPerBlockOptin, dev);
  STD_TORCH_CHECK(max_shared_mem > 0);

  int major_capability, minor_capability;
  cudaDeviceGetAttribute(&major_capability, cudaDevAttrComputeCapabilityMajor,
                         dev);
  cudaDeviceGetAttribute(&minor_capability, cudaDevAttrComputeCapabilityMinor,
                         dev);
  STD_TORCH_CHECK(major_capability * 10 + minor_capability >= 75,
                  "marlin kernel only support Turing or newer GPUs.");
  int stages = 4;
  if (major_capability == 7 && minor_capability == 5) {
    stages = 2;
    STD_TORCH_CHECK(a_type == vllm::kFloat16 || a_type == vllm::kS8,
                    "Turing only support FP16 or INT8 activation.");
  }
  if (a_type == vllm::kFE4M3fn) {
    STD_TORCH_CHECK(major_capability * 10 + minor_capability >= 89,
                    "FP8 only support Ada Lovelace or newer GPUs.");
    STD_TORCH_CHECK(
        major_capability * 10 + minor_capability == 89 ||
            major_capability == 12,
        "Marlin W4A8-FP8 only support SM89 or SM12x device (It is slower than "
        "Marlin W4A16 on other devices).");
  }

  // Set thread config
  exec_config_t exec_cfg;
  thread_config_t thread_tfg;
  if (thread_k != -1 && thread_n != -1) {
    thread_tfg = thread_config_t{thread_k, thread_n, thread_k * thread_n / 64};
    if (blocks_per_sm == -1) blocks_per_sm = 1;
    exec_cfg = exec_config_t{blocks_per_sm, thread_tfg};
    STD_TORCH_CHECK(prob_n % thread_n == 0, "prob_n = ", prob_n,
                    " is not divisible by thread_n = ", thread_n);
    STD_TORCH_CHECK(prob_k % thread_k == 0, "prob_k = ", prob_k,
                    " is not divisible by thread_k = ", thread_k);
  } else {
    // Auto config
    exec_cfg = determine_exec_config(
        a_type, b_type, c_type, s_type, prob_m, prob_n, prob_k, num_experts,
        top_k, thread_m_blocks, m_block_size_8, num_bits, group_size, has_zp,
        is_zp_float, is_a_8bit, stages, max_shared_mem, sms);
    thread_tfg = exec_cfg.tb_cfg;
  }

  int num_threads = thread_tfg.num_threads;
  thread_k = thread_tfg.thread_k;
  thread_n = thread_tfg.thread_n;
  int blocks = sms * exec_cfg.blocks_per_sm;
  if (exec_cfg.blocks_per_sm > 1)
    max_shared_mem = max_shared_mem / exec_cfg.blocks_per_sm - 1024;

  int thread_k_blocks = thread_k / 16;
  int thread_n_blocks = thread_n / 16;

  STD_TORCH_CHECK(
      is_valid_config(thread_tfg, m_block_size_8, thread_m_blocks, prob_m,
                      prob_n, prob_k, num_bits, group_size, has_zp, is_zp_float,
                      is_a_8bit, stages, max_shared_mem),
      "Invalid thread config: thread_m_blocks = ", thread_m_blocks,
      ", thread_k = ", thread_tfg.thread_k,
      ", thread_n = ", thread_tfg.thread_n,
      ", num_threads = ", thread_tfg.num_threads, " for MKN = [", prob_m, ", ",
      prob_k, ", ", prob_n, "] and num_bits = ", num_bits,
      ", group_size = ", group_size, ", has_zp = ", has_zp,
      ", is_zp_float = ", is_zp_float, ", max_shared_mem = ", max_shared_mem);

  int sh_cache_size = get_kernel_cache_size(
      thread_tfg, m_block_size_8, thread_m_blocks, prob_m, prob_n, prob_k,
      num_bits, group_size, has_zp, is_zp_float, is_a_8bit, stages);

  auto kernel =
      get_marlin_kernel(a_type, b_type, c_type, s_type, thread_m_blocks,
                        thread_n_blocks, thread_k_blocks, m_block_size_8,
                        has_zp, group_blocks, num_threads, is_zp_float, stages);

  if (kernel == MarlinDefault) {
    STD_TORCH_CHECK(false, "Unsupported shapes: MNK = [", prob_m, ", ", prob_n,
                    ", ", prob_k, "]", ", group_size = ", group_size,
                    ", thread_m_blocks = ", thread_m_blocks,
                    ", thread_n_blocks = ", thread_n_blocks,
                    ", thread_k_blocks = ", thread_k_blocks,
                    ", num_bits = ", num_bits);
  }

  cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize,
                       max_shared_mem);
  // avoid ">>>" being formatted to "> > >"
  // clang-format off
  kernel<<<blocks, num_threads, max_shared_mem, stream>>>(
      A_ptr, B_ptr, C_ptr, C_tmp_ptr, bias_ptr, a_s_ptr, b_s_ptr, g_s_ptr, zp_ptr,
      sorted_token_ids_ptr, expert_ids_ptr, num_tokens_past_padded_ptr,
      topk_weights_ptr, top_k, mul_topk_weights, prob_m, prob_n, prob_k, locks,
      has_bias, use_atomic_add, use_fp32_reduce);
  // clang-format on
}

}  // namespace MARLIN_NAMESPACE_NAME

torch::stable::Tensor moe_wna16_marlin_gemm(
    torch::stable::Tensor& a, std::optional<torch::stable::Tensor> c_or_none,
    torch::stable::Tensor& b_q_weight,
    std::optional<torch::stable::Tensor> const& b_bias_or_none,
    torch::stable::Tensor& b_scales,
    std::optional<torch::stable::Tensor> const& a_scales_or_none,
    std::optional<torch::stable::Tensor> const& global_scale_or_none,
    std::optional<torch::stable::Tensor> const& b_zeros_or_none,
    torch::stable::Tensor& workspace, torch::stable::Tensor& sorted_token_ids,
    torch::stable::Tensor& expert_ids,
    torch::stable::Tensor& num_tokens_past_padded,
    torch::stable::Tensor& topk_weights, int64_t moe_block_size, int64_t top_k,
    bool mul_topk_weights, vllm::ScalarTypeId const& b_type_id, int64_t size_m,
    int64_t size_n, int64_t size_k, bool use_atomic_add, bool use_fp32_reduce,
    bool is_zp_float, int64_t thread_k, int64_t thread_n,
    int64_t blocks_per_sm) {
  vllm::ScalarTypeId a_type_id, c_type_id, s_type_id;

  auto c_dtype = a.scalar_type();
  if (a.scalar_type() == torch::headeronly::ScalarType::Half) {
    a_type_id = vllm::kFloat16.id();
    c_type_id = vllm::kFloat16.id();
  } else if (a.scalar_type() == torch::headeronly::ScalarType::BFloat16) {
    a_type_id = vllm::kBFloat16.id();
    c_type_id = vllm::kBFloat16.id();
  } else {
    c_dtype = b_scales.scalar_type();
    if (b_scales.scalar_type() == torch::headeronly::ScalarType::Half) {
      c_type_id = vllm::kFloat16.id();
    } else if (b_scales.scalar_type() ==
               torch::headeronly::ScalarType::BFloat16) {
      c_type_id = vllm::kBFloat16.id();
    } else {
      c_type_id = vllm::kBFloat16.id();

      STD_TORCH_CHECK(c_or_none.has_value(), "c must be passed for W4A8-FP4");
      torch::stable::Tensor c = c_or_none.value();
      c_dtype = c.scalar_type();

      if (c.scalar_type() == torch::headeronly::ScalarType::Half) {
        c_type_id = vllm::kFloat16.id();
      } else if (c.scalar_type() == torch::headeronly::ScalarType::BFloat16) {
        c_type_id = vllm::kBFloat16.id();
      } else {
        STD_TORCH_CHECK(false, "unsupported c dtype");
      }
    }

    if (a.scalar_type() == torch::headeronly::ScalarType::Float8_e4m3fn) {
      a_type_id = vllm::kFE4M3fn.id();
    } else if (a.scalar_type() == torch::headeronly::ScalarType::Char) {
      a_type_id = vllm::kS8.id();
    } else {
      STD_TORCH_CHECK(false, "unsupported `a` scalar_type");
    }
  }

  s_type_id = c_type_id;
  if (b_type_id == vllm::kFE2M1f.id()) {
    if (b_scales.scalar_type() ==
        torch::headeronly::ScalarType::Float8_e4m3fn) {
      s_type_id = vllm::kFE4M3fn.id();
    } else if (b_scales.scalar_type() ==
               torch::headeronly::ScalarType::Float8_e8m0fnu) {
      s_type_id = vllm::kFE8M0fnu.id();
    } else {
      STD_TORCH_CHECK(
          false, "When b_type = float4_e2m1f, b_scale scalar type must be",
          "float8_e4m3fn (for NVFP4) or float8_e8m0fnu (for MXFP4).");
    }
  } else if (b_type_id == vllm::kFE4M3fn.id() &&
             b_scales.scalar_type() ==
                 torch::headeronly::ScalarType::Float8_e8m0fnu) {
    s_type_id = vllm::kFE8M0fnu.id();
  }

  vllm::ScalarType a_type = vllm::ScalarType::from_id(a_type_id);
  vllm::ScalarType b_type = vllm::ScalarType::from_id(b_type_id);
  vllm::ScalarType c_type = vllm::ScalarType::from_id(c_type_id);
  vllm::ScalarType s_type = vllm::ScalarType::from_id(s_type_id);

  int pack_factor = 32 / b_type.size_bits();
  int num_experts = b_q_weight.size(0);

  if (moe_block_size != 8) {
    STD_TORCH_CHECK(moe_block_size % 16 == 0,
                    "unsupported moe_block_size=", moe_block_size);
    STD_TORCH_CHECK(moe_block_size >= 16 && moe_block_size <= 64,
                    "unsupported moe_block_size=", moe_block_size);
  }

  // Verify A
  STD_TORCH_CHECK(a.size(0) == size_m,
                  "Shape mismatch: a.size(0) = ", a.size(0),
                  ", size_m = ", size_m);
  STD_TORCH_CHECK(a.size(1) == size_k,
                  "Shape mismatch: a.size(1) = ", a.size(1),
                  ", size_k = ", size_k);

  // Verify B
  STD_TORCH_CHECK(
      size_k % MARLIN_NAMESPACE_NAME::tile_size == 0, "size_k = ", size_k,
      " is not divisible by tile_size = ", MARLIN_NAMESPACE_NAME::tile_size);
  STD_TORCH_CHECK(
      (size_k / MARLIN_NAMESPACE_NAME::tile_size) == b_q_weight.size(1),
      "Shape mismatch: b_q_weight.size(1) = ", b_q_weight.size(1),
      ", size_k = ", size_k,
      ", tile_size = ", MARLIN_NAMESPACE_NAME::tile_size);
  STD_TORCH_CHECK(
      b_q_weight.size(2) % MARLIN_NAMESPACE_NAME::tile_size == 0,
      "b_q_weight.size(2) = ", b_q_weight.size(2),
      " is not divisible by tile_size = ", MARLIN_NAMESPACE_NAME::tile_size);
  int actual_size_n =
      (b_q_weight.size(2) / MARLIN_NAMESPACE_NAME::tile_size) * pack_factor;
  STD_TORCH_CHECK(size_n == actual_size_n, "size_n = ", size_n,
                  ", actual_size_n = ", actual_size_n);

  // Verify device and strides
  STD_TORCH_CHECK(a.device().is_cuda(), "A is not on GPU");
  STD_TORCH_CHECK(a.is_contiguous(), "A is not contiguous");

  STD_TORCH_CHECK(b_q_weight.device().is_cuda(), "b_q_weight is not on GPU");
  STD_TORCH_CHECK(b_q_weight.is_contiguous(), "b_q_weight is not contiguous");

  STD_TORCH_CHECK(b_scales.device().is_cuda(), "b_scales is not on GPU");
  STD_TORCH_CHECK(b_scales.is_contiguous(), "b_scales is not contiguous");

  torch::stable::Tensor a_scales;
  constexpr auto kFloat = torch::headeronly::ScalarType::Float;

  if (a_scales_or_none.has_value()) {
    a_scales = a_scales_or_none.value();
    STD_TORCH_CHECK(a_type.size_bits() == 8,
                    "a_scales can only be used for 8bit activation.");
  } else {
    a_scales = torch::stable::new_empty(a, {0}, kFloat);
    STD_TORCH_CHECK(
        a_type.size_bits() != 8,
        "the a_scales parameter must be passed for 8bit activation.");
  }

  // sms: number of SMs to use for the kernel
  int sms = -1;
  cudaDeviceGetAttribute(&sms, cudaDevAttrMultiProcessorCount, a.get_device());

  // Alloc buffers
  torch::stable::accelerator::DeviceGuard device_guard(a.get_device_index());
  torch::stable::Tensor c;
  if (c_or_none.has_value()) {
    c = c_or_none.value();
    STD_TORCH_CHECK(c.device().is_cuda(), "c is not on GPU");
    STD_TORCH_CHECK(c.is_contiguous(), "c is not contiguous");
    STD_TORCH_CHECK(c.size(0) == size_m * top_k,
                    "Shape mismatch: c.size(0) = ", c.size(0),
                    ", size_m * topk = ", size_m * top_k);
    STD_TORCH_CHECK(c.size(1) == size_n,
                    "Shape mismatch: c.size(1) = ", c.size(1),
                    ", size_n = ", size_n);
  } else {
    c = torch::stable::new_empty(a, {size_m * top_k, size_n}, c_dtype);
  }

  // Alloc C tmp buffer that is going to be used for the global reduce
  torch::stable::Tensor c_tmp;
  if (use_fp32_reduce && !use_atomic_add) {
    // max num of threadblocks is sms * 4
    long max_c_tmp_size = min(
        (long)size_n * sorted_token_ids.size(0),
        (long)sms * 4 * moe_block_size * MARLIN_NAMESPACE_NAME::max_thread_n);
    if (moe_block_size == 8) max_c_tmp_size *= 2;
    c_tmp = torch::stable::new_empty(a, {max_c_tmp_size}, kFloat);
  } else {
    c_tmp = torch::stable::new_empty(a, {0}, kFloat);
  }

  // Detect group size.
  int num_groups = -1;
  int group_size = -1;

  int rank = b_scales.dim();
  STD_TORCH_CHECK(rank == 3, "b_scales rank = ", rank, " is not 3");
  STD_TORCH_CHECK(b_scales.size(2) == size_n,
                  "b_scales dim 2 = ", b_scales.size(2),
                  " is not size_n = ", size_n);
  num_groups = b_scales.size(1);

  if (num_groups > 1) {
    STD_TORCH_CHECK(
        size_k % num_groups == 0, "size_k = ", size_k,
        ", is not divisible by b_scales.size(1) = ", b_scales.size(1));
    group_size = size_k / num_groups;
  } else {
    group_size = -1;
  }

  torch::stable::Tensor global_scale;
  if (global_scale_or_none.has_value()) {
    global_scale = global_scale_or_none.value();
    STD_TORCH_CHECK(b_type == vllm::kFE2M1f && s_type == vllm::kFE4M3fn,
                    "global_scale can only be used for nvfp4 format.");
  } else {
    global_scale = torch::stable::new_empty(a, {0}, kFloat);
    STD_TORCH_CHECK(
        !(b_type == vllm::kFE2M1f && s_type == vllm::kFE4M3fn),
        "the global_scale parameter must be passed for nvfp4 format.");
  }

  bool has_bias = b_bias_or_none.has_value();
  torch::stable::Tensor b_bias;
  if (has_bias) {
    b_bias = b_bias_or_none.value();
    STD_TORCH_CHECK(b_bias.device().is_cuda(), "b_bias is not on GPU");
    STD_TORCH_CHECK(b_bias.is_contiguous(), "b_bias is not contiguous");
    STD_TORCH_CHECK(b_bias.size(1) == size_n, "b_bias.size(1) != size_n");
    STD_TORCH_CHECK(b_bias.stride(1) == 1, "b_bias.stride(1) != 1");
  } else {
    b_bias = torch::stable::new_empty(a, {0}, c_dtype);
  }

  torch::stable::Tensor b_zeros;
  if (b_zeros_or_none.has_value()) {
    b_zeros = b_zeros_or_none.value();
    STD_TORCH_CHECK(b_zeros.device().is_cuda(), "b_zeros is not on GPU");
    STD_TORCH_CHECK(b_zeros.is_contiguous(), "b_zeros is not contiguous");
  } else {
    b_zeros = torch::stable::new_empty(a, {0}, c_dtype);
  }
  bool has_zp = b_zeros.size(-1) > 0;
  if (has_zp) {
    STD_TORCH_CHECK(
        b_type == vllm::kU4 || b_type == vllm::kU8,
        "b_type must be u4 or u8 when has_zp = True. Got = ", b_type.str());
  } else {
    STD_TORCH_CHECK(b_type == vllm::kU4B8 || b_type == vllm::kU8B128 ||
                        b_type == vllm::kS4 || b_type == vllm::kS8 ||
                        b_type == vllm::kFE4M3fn || b_type == vllm::kFE2M1f,
                    "b_type must be uint4b8, uint8b128, int4, int8, "
                    "float8_e4m3fn or float4_e2m1f when has_zp = False. Got = ",
                    b_type.str());
  }

  if (has_zp && is_zp_float) {
    STD_TORCH_CHECK(
        a.scalar_type() == torch::headeronly::ScalarType::Half,
        "Computation type must be float16 (half) when using float zero "
        "points.");
  }

  // Verify b_zeros
  if (has_zp) {
    int rank = b_zeros.dim();
    STD_TORCH_CHECK(rank == 3, "b_zeros rank = ", rank, " is not 3");
    if (is_zp_float) {
      STD_TORCH_CHECK(b_zeros.size(2) == size_n,
                      "b_zeros dim 2 = ", b_zeros.size(2),
                      " is not size_n = ", size_n);
      STD_TORCH_CHECK(num_groups == b_zeros.size(1),
                      "b_zeros dim 1 = ", b_zeros.size(1),
                      " is not num_groups = ", num_groups);
      STD_TORCH_CHECK(num_groups != -1, "num_groups must be != -1");
    } else {
      STD_TORCH_CHECK(b_zeros.size(1) == num_groups,
                      "b_zeros dim 1 = ", b_zeros.size(1),
                      " is not num_groups = ", num_groups);
      STD_TORCH_CHECK(b_zeros.size(2) == size_n / pack_factor,
                      "b_zeros dim 2 = ", b_zeros.size(2),
                      " is not size_n / pack_factor = ", size_n / pack_factor);
    }
  }

  // Verify workspace size
  STD_TORCH_CHECK(size_n % MARLIN_NAMESPACE_NAME::min_thread_n == 0,
                  "size_n = ", size_n, ", is not divisible by min_thread_n = ",
                  MARLIN_NAMESPACE_NAME::min_thread_n);

  int max_n_tiles = size_n / MARLIN_NAMESPACE_NAME::min_thread_n;
  int min_workspace_size = min(
      max_n_tiles * (int)(sorted_token_ids.size(0) / moe_block_size), sms * 4);
  STD_TORCH_CHECK(workspace.numel() >= min_workspace_size,
                  "workspace.numel = ", workspace.numel(),
                  " is below min_workspace_size = ", min_workspace_size);

  int dev = a.get_device();

  STD_TORCH_CHECK(
      a_scales.scalar_type() == torch::headeronly::ScalarType::Float,
      "scalar type of a_scales must be float");
  STD_TORCH_CHECK(
      global_scale.scalar_type() == torch::headeronly::ScalarType::Float,
      "scalar type of global_scale must be float");
  if (a_type.size_bits() == 16) {
    STD_TORCH_CHECK(
        a.scalar_type() == c.scalar_type(),
        "scalar type of a must be the same with c for 16 bit activation");
  }

  MARLIN_NAMESPACE_NAME::marlin_mm(
      a.const_data_ptr(), b_q_weight.const_data_ptr(), c.mutable_data_ptr(),
      c_tmp.mutable_data_ptr(), b_bias.mutable_data_ptr(),
      a_scales.mutable_data_ptr(), b_scales.mutable_data_ptr(),
      global_scale.mutable_data_ptr(), b_zeros.mutable_data_ptr(),
      sorted_token_ids.mutable_data_ptr(), expert_ids.mutable_data_ptr(),
      num_tokens_past_padded.mutable_data_ptr(),
      topk_weights.mutable_data_ptr(), moe_block_size, num_experts, top_k,
      mul_topk_weights, size_m, size_n, size_k, workspace.mutable_data_ptr(),
      a_type, b_type, c_type, s_type, has_bias, has_zp, group_size, dev,
      get_current_cuda_stream(dev), thread_k, thread_n, sms, blocks_per_sm,
      use_atomic_add, use_fp32_reduce, is_zp_float);

  return c;
}

STABLE_TORCH_LIBRARY_IMPL(_moe_C, CUDA, m) {
  m.impl("moe_wna16_marlin_gemm", TORCH_BOX(&moe_wna16_marlin_gemm));
}

"""CPU-only exact TP2 byte-offset storage count, bound to the earlier full scan."""
import hashlib,json,time
from pathlib import Path
import numpy as np
started=time.time();root=Path('/model');prior=Path('/prior')
records=json.loads((prior/'tensor-review.json').read_text());output=[];sums=[{'source':0,'retained':0,'parts':0,'fallbacks':0} for _ in range(2)]
for d in records:
 with (root/d['file']).open('rb') as f:f.seek(d['offset']);raw=f.read(d['bytes'])
 assert hashlib.sha256(raw).hexdigest()==d['sha256']
 a=np.frombuffer(raw,np.uint8).reshape(d['shape'])
 assert int(a.min())>=8 and int(a.max())<127
 for rank in (0,1):
  part=a[:,rank*64:(rank+1)*64] if d['projection']=='down_proj' else a[rank*1024:(rank+1)*1024]
  lo,hi=int(part.min()),int(part.max());fallback=hi-lo>=32
  size=part.size+32 if fallback else part.size*5//8+32+32
  sums[rank]['source']+=part.size;sums[rank]['retained']+=size;sums[rank]['parts']+=1;sums[rank]['fallbacks']+=fallback
  output.append({'name':d['name'],'rank':rank,'min':lo,'max':hi,'fallback':fallback,'retained_bytes':size})
for r in sums:r['retained']+=42*2*24;r['saved_GiB']=(r['source']-r['retained'])/1024**3
result={'status':'complete','started':started,'finished':time.time(),'tensor_count':len(records),'ranks':sums,'assumptions':['Source bytes are finite positive normal E4M3; the existing power-of-two Marlin transformation preserves byte span within each projection','Exact byte-offset eligibility and byte recovery verified separately on actual post-Marlin GPU fixtures','Counts include 32-byte per-part pointer table, 32-byte palette for eligible parts, and 24-byte per-family descriptor; allocator rounding and model integration are not measured'],'parts':output}
Path('/result/full-range-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'ranks':sums,'seconds':result['finished']-started}))

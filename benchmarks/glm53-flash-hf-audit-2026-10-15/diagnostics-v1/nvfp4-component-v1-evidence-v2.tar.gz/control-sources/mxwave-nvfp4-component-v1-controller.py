import hashlib,json,subprocess,tarfile,time,urllib.request
from pathlib import Path
ROOT=Path('/home/kirya/local-spark/experiments/glm53-mxfp4-audit-2026-10-15/full-model-v1/nvfp4-component-v1')
NAME='mxwave-nvfp4-component-v1-test1'
OUT=ROOT/'test1';OUT.mkdir(exist_ok=False)
state={'status':'preparing','started':time.time()};active=False

def save():
 p=ROOT/'controller.json';tmp=p.with_suffix('.pending');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(p)
def activity():
 raw=urllib.request.urlopen('http://127.0.0.1:8000/metrics',timeout=5).read().decode()
 gauges={};counters={}
 for line in raw.splitlines():
  if line.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{')):
   key,value=line.rsplit(' ',1);gauges[key]=float(value)
  if line.startswith(('vllm:prompt_tokens_total{','vllm:generation_tokens_total{','vllm:request_success_total{')):
   key,value=line.rsplit(' ',1);counters[key]=float(value)
 assert gauges and counters
 return {'gauges':gauges,'counters':counters,'busy':any(gauges.values()),'epoch':time.time()}
def identity():
 d=json.loads(subprocess.check_output(['docker','inspect','mxwave-serving-trial-v2-candidate-r0'],text=True))[0]
 return {'id':d['Id'],'started':d['State']['StartedAt'],'running':d['State']['Running'],'image':d['Image']}
try:
 with tarfile.open('/tmp/mxwave-nvfp4-component-v1-harness.tar.gz') as t:
  (ROOT/'harness').mkdir(exist_ok=False);t.extractall(ROOT/'harness',filter='data')
 state['harness_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'harness').iterdir()}
 state['live_before']=identity();before=activity();time.sleep(3);second=activity()
 if before['busy'] or second['busy'] or before['counters']!=second['counters']:
  raise RuntimeError('Service not idle; GPU test not started')
 state['before']=second
 args=['docker','run','-d','--name',NAME,'--gpus','all','--network','none','--cpus','2','--memory','4g','--memory-swap','4g','--pids-limit','512','-e','PYTHONPATH=/experiment/harness','-e','PYTHONDONTWRITEBYTECODE=1','-e','OMP_NUM_THREADS=1','-e','OPENBLAS_NUM_THREADS=1','-e','VLLM_CACHE_ROOT=/result/cache/vllm','-e','CUDA_CACHE_PATH=/result/cache/cuda','-e','TRITON_CACHE_DIR=/result/cache/triton','-v',str(ROOT)+':/experiment:ro','-v',str(OUT)+':/result:rw','-v','/home/kirya/local-spark/models/glm-5.3-flash/derived/glm-quant-mix/lossless8:/model:ro','--entrypoint','/usr/bin/timeout','sha256:39a03677234ea74e35544d301bd14716c1ae9695ad8d91b16e2c76545e26e8d2','900','python3','-B','-u','/experiment/harness/benchmark.py','--model','/model','--native','/experiment/native','--output','/result']
 state['argv']=args;state['container_id']=subprocess.check_output(args,text=True).strip();active=True;state['status']='running';save()
 for _ in range(910):
  now=activity();state['last_activity']=now
  if now['busy'] or now['counters']!=second['counters']:
   state['status']='interrupted_live_activity';break
  inspect=json.loads(subprocess.check_output(['docker','inspect',NAME],text=True))[0]
  if not inspect['State']['Running']:
   active=False;state['container_state']=inspect['State'];state['status']='complete' if inspect['State']['ExitCode']==0 else 'failed';break
  save();time.sleep(1)
 else:state['status']='timeout'
except BaseException as err:
 state.update(status='controller_failed',error=repr(err))
finally:
 if active:subprocess.run(['docker','stop','--time','2',NAME],stdout=subprocess.DEVNULL,check=False)
 state['after']=activity();state['live_after']=identity();state['live_unchanged']=state['live_before']==state['live_after'];state['health_200']=urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=5).status==200
 log=subprocess.run(['docker','logs',NAME],capture_output=True,text=True);(OUT/'container.log').write_text(log.stdout+log.stderr)
 state['finished']=time.time();save()

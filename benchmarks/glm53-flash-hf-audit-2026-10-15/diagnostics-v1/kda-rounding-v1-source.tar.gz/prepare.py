"""Freeze disposable stock-CT launch, tokenized cases and both-rank source proofs."""

from __future__ import annotations

import copy
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).parent
CODE = ROOT.parent / "full-c16admissionv1-src"
sys.path.insert(0, str(CODE))
import full_model_control as c


def set_option(command, flag, value):
    command[command.index(flag) + 1] = value


def main():
    assert not (ROOT / "prepared.json").exists()
    prior = json.loads((ROOT.parent / "mxfp4-serving-v3/prepared.json").read_bytes())
    bindings = [c.preflight(rank, CODE) for rank in (0, 1)]
    assert bindings == prior["bindings"]
    plan = json.loads((ROOT / "plan-draft.json").read_bytes())
    # Offline tokenization has no model load or GPU access.
    script = """
from pathlib import Path
import json
from transformers import AutoTokenizer
t=AutoTokenizer.from_pretrained('/model',local_files_only=True)
plan=json.loads(Path('/trial/plan-draft.json').read_bytes())
rows=[]
for task in plan['tasks']:
 ids=t.apply_chat_template([{'role':'user','content':task['prompt']}],tokenize=True,add_generation_prompt=True,enable_thinking=False)
 if not isinstance(ids,list): ids=ids['input_ids']
 assert 0<len(ids)<512
 rows.append({'name':'short_'+task['name'],'tokens':ids,'kind':'short_task'})
print(json.dumps(rows))
"""
    source = ROOT.parent / "source"
    run = subprocess.run([
        "docker", "run", "--rm", "--network", "none", "--cpus", "2", "--memory", "3g",
        "-e", "CUDA_VISIBLE_DEVICES=", "-e", "NVIDIA_VISIBLE_DEVICES=void",
        "-e", "HF_HUB_OFFLINE=1", "-e", "TRANSFORMERS_OFFLINE=1",
        "-v", f"{source}:/model:ro", "-v", f"{ROOT}:/trial:ro",
        "--entrypoint", "/usr/bin/python3", c.IMAGE, "-c", script,
    ], capture_output=True, text=True, timeout=240, check=False)
    (ROOT / "tokenize.log").write_text(run.stderr)
    assert run.returncode == 0, run.stderr[-2000:]
    plan["cases"].extend(json.loads(run.stdout.strip().splitlines()[-1]))
    c.write(ROOT / "plan.json", plan)
    subprocess.run([
        "scp", "-i", "/home/kirya/.ssh/id_glm_cluster", str(ROOT / "plan.json"),
        f"kirya@192.168.192.2:{ROOT}/plan.json",
    ], check=True, timeout=60)
    entries = copy.deepcopy(prior["launches"]["a1"])
    for rank, entry in enumerate(entries):
        command = entry["command"]
        for flag in ("--speculative-config", "--profiler-config"):
            at = command.index(flag)
            del command[at:at + 2]
        for flag, value in (
            ("--port", "8013"), ("--master-port", "29686"), ("--max-logprobs", "154880"),
            ("--worker-extension-cls", "kda_rounding_worker.KdaRoundingWorker"),
        ):
            set_option(command, flag, value)
        entry["mounts"] = [m for m in entry["mounts"] if m[1] != "/draft"]
        for mount in entry["mounts"]:
            if mount[1] == "/trial":
                mount[0] = str(ROOT)
            if mount[1] == "/traces":
                mount[0] = str(ROOT / f"engine-r{rank}")
                c.run(rank, ["mkdir", "-p", mount[0]])
        name = f"mxwave-kda-rounding-v1-r{rank}"
        assert not c.run(rank, ["docker", "ps", "-aq", "--filter", f"name=^/{name}$"]).strip()
        argv = [
            "docker", "run", "-d", "--name", name, "--gpus", "all", "--network", "host",
            "--ipc", "host", "--memory", "112g", "--memory-swap", "112g",
            "--cap-add", "IPC_LOCK", "--security-opt", "label=disable",
            "--device", "/dev/infiniband", "--ulimit", "memlock=-1",
            "--ulimit", "stack=67108864", "--ulimit", "nofile=1048576",
        ]
        for src, target, access in entry["mounts"]:
            argv += ["-v", f"{src}:{target}:{access}"]
        for key, value in entry["environment"].items():
            argv += ["-e", key + "=" + value]
        argv += ["--entrypoint", "/usr/bin/python3", c.IMAGE, "-u", "/trial/trial_boot.py", *command]
        entry.update(name=name, argv=argv)
    entry = entries[0]
    argv = [
        "docker", "run", "--rm", "--network", "none", "--cpus", "2",
        "--memory", "3g", "--memory-swap", "3g",
        "-e", "CUDA_VISIBLE_DEVICES=", "-e", "NVIDIA_VISIBLE_DEVICES=void",
        "-e", "MXWAVE_VALIDATE_ONLY=1", "-e", "UV_CACHE_DIR=/tmp/mxwave-uv-cache",
    ]
    for src, target, access in entry["mounts"]:
        if "/secrets/" not in src:
            argv += ["-v", f"{src}:{target}:{access}"]
    for key, value in entry["environment"].items():
        argv += ["-e", key + "=" + value]
    argv += [
        "--entrypoint", "/usr/bin/python3", c.IMAGE, "-u", "/trial/trial_boot.py", *entry["command"],
    ]
    run = subprocess.run(argv, capture_output=True, text=True, timeout=240, check=False)
    (ROOT / "cpu-check.log").write_text(run.stdout + "\n" + run.stderr)
    assert run.returncode == 0, run.stderr[-3000:]
    manifest = {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(ROOT.iterdir()) if p.suffix == ".py" or p.name == "plan.json"
    }
    c.write(ROOT / "source-manifest.json", manifest)
    subprocess.run([
        "scp", "-i", "/home/kirya/.ssh/id_glm_cluster", str(ROOT / "source-manifest.json"),
        f"kirya@192.168.192.2:{ROOT}/source-manifest.json",
    ], check=True, timeout=60)
    check = (
        "import hashlib,json,pathlib,sys;p=pathlib.Path(sys.argv[1]);"
        "m=json.loads((p/'source-manifest.json').read_bytes());"
        "assert all(hashlib.sha256((p/k).read_bytes()).hexdigest()==v for k,v in m.items());"
        "print(len(m))"
    )
    assert int(c.run(1, ["python3", "-S", "-c", check, str(ROOT)])) == len(manifest)
    result = {
        "status": "passed", "bindings": bindings, "live": prior["originals"],
        "originals": prior["originals"], "launches": {"engine": entries},
        "plan_sha256": hashlib.sha256((ROOT / "plan.json").read_bytes()).hexdigest(),
        "cpu_check_sha256": hashlib.sha256((ROOT / "cpu-check.log").read_bytes()).hexdigest(),
    }
    c.write(ROOT / "prepared.json", result)
    print(json.dumps({
        "status": "passed", "contexts": len(plan["cases"]),
        "heldout_tokens_per_leg": plan["wiki_scored_tokens"],
        "runtime_bindings": len(bindings[0]["code"]), "diagnostic_bindings": len(manifest),
    }))


if __name__ == "__main__":
    main()

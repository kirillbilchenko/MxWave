"""Collect paired fixed-history logits, held-out log loss and short natural answers."""

from __future__ import annotations

import hashlib
import json
import math
import pathlib
import time
import urllib.request

ROOT = pathlib.Path(__file__).parent
BASE = "http://127.0.0.1:8013"


def write(path, value):
    temp = path.with_suffix(".incomplete")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temp.replace(path)


def request(route, body=None, timeout=600):
    key = pathlib.Path("/home/kirya/local-spark/runtime/secrets/llm_api_key").read_text().strip()
    q = urllib.request.Request(
        BASE + route, data=None if body is None else json.dumps(body).encode(),
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(q, timeout=timeout) as response:
        return json.load(response)


def rpc(method, *args):
    result = request("/collective_rpc", {
        "method": method, "args": list(args), "kwargs": {}, "timeout": 600,
    }, timeout=660)
    assert len(result["results"]) == 2
    assert all(row["status"] in ("complete", "armed") for row in result["results"])
    return result["results"]


def completion(ids, count, prompt_logprobs=False):
    body = {
        "model": "glm-5.3-flash", "prompt": ids, "max_tokens": count,
        "min_tokens": count, "temperature": 0, "seed": 42, "ignore_eos": True,
        "return_token_ids": True,
    }
    if prompt_logprobs:
        body["prompt_logprobs"] = 1
    value = request("/v1/completions", body)
    assert value["usage"]["prompt_tokens"] == len(ids)
    assert value["usage"]["completion_tokens"] == count
    assert len(value["choices"][0]["token_ids"]) == count
    return value


def natural(task):
    return request("/v1/chat/completions", {
        "model": "glm-5.3-flash", "messages": [{"role": "user", "content": task["prompt"]}],
        "temperature": 0, "seed": 42, "max_tokens": task["max_tokens"],
        "chat_template_kwargs": {"enable_thinking": False},
    })


def main():
    plan = json.loads((ROOT / "plan.json").read_bytes())
    path = ROOT / "measurement.json"
    assert not path.exists()
    state = {
        "status": "running", "started_epoch": time.time(),
        "plan_sha256": hashlib.sha256((ROOT / "plan.json").read_bytes()).hexdigest(),
        "legs": {}, "forced_sequences": {}, "models": request("/v1/models"),
    }
    write(path, state)
    try:
        state["initialization"] = rpc("mxwave_rounding_initialize")
        write(path, state)
        # Warm one long and one short shape before retaining the baseline.
        for ids in (plan["wiki_windows"][0], plan["cases"][0]["tokens"]):
            completion(ids, 1, prompt_logprobs=True)
        for label in plan["legs"]:
            state["phase"] = label
            if label == "b1":
                state["quantization"] = rpc("mxwave_rounding_set", "mxfp8_roundtrip")
            elif label == "a3":
                state["weight_restore"] = rpc("mxwave_rounding_set", "original")
            leg = {
                "status": "running", "mode": plan["mode_by_leg"][label],
                "contexts": [], "heldout": [], "tasks": [], "started_epoch": time.time(),
            }
            state["legs"][label] = leg
            write(path, state)
            for case in plan["cases"]:
                name = label + "_" + case["name"]
                forced = state["forced_sequences"].get(case["name"])
                rpc("mxwave_rounding_arm", name, plan["decode_tokens"], forced, case["tokens"])
                response = completion(case["tokens"], plan["decode_tokens"])
                capture = rpc("mxwave_rounding_disarm")
                ids = response["choices"][0]["token_ids"]
                if forced is None:
                    state["forced_sequences"][case["name"]] = ids
                else:
                    assert ids == forced, (label, case["name"], "Forced token history changed")
                row = {
                    "name": case["name"], "kind": case["kind"],
                    "prompt_sha256": hashlib.sha256(
                        json.dumps(case["tokens"], separators=(",", ":")).encode()
                    ).hexdigest(),
                    "token_ids": ids, "captured_unmodified_logits": capture,
                    "API_usage": response["usage"],
                    "API_logprobs_used_for_KL": False,
                }
                leg["contexts"].append(row)
                write(path, state)
            for index, ids in enumerate(plan["wiki_windows"]):
                response = completion(ids, 1, prompt_logprobs=True)
                probs = response["choices"][0]["prompt_logprobs"]
                assert len(probs) == len(ids)
                values = [
                    float(row[str(token)]["logprob"])
                    for token, row in zip(ids[1:], probs[1:], strict=True)
                ]
                assert len(values) == 1024 and all(math.isfinite(x) for x in values)
                raw_path = ROOT / f"{label}-wiki-{index:02d}.json"
                assert not raw_path.exists()
                write(raw_path, response)
                leg["heldout"].append({
                    "index": index, "tokens": len(values), "logprobs": values,
                    "file": raw_path.name,
                    "sha256": hashlib.sha256(raw_path.read_bytes()).hexdigest(),
                })
                write(path, state)
            if label in ("a1", "b1", "a3"):
                for task in plan["tasks"]:
                    response = natural(task)
                    leg["tasks"].append({"name": task["name"], "response": response})
                    write(path, state)
            leg.update(status="complete", finished_epoch=time.time())
            write(path, state)
        state.update(status="complete", phase="complete", finished_epoch=time.time())
        write(path, state)
    except BaseException as exc:
        state.update(status="failed", error=repr(exc), finished_epoch=time.time())
        write(path, state)
        raise


if __name__ == "__main__":
    main()

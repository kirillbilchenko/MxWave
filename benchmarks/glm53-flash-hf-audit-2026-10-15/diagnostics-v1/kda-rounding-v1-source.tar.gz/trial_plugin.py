"""Preserve the established startup preparation; do not mutate model weights at load."""

from __future__ import annotations

import functools
import hashlib
import inspect
import json
from pathlib import Path


def install():
    from vllm.v1.worker.gpu_worker import Worker
    expected = json.loads(Path("/trial/plan.json").read_bytes())["gpu_worker_sha256"]
    assert hashlib.sha256(Path(inspect.getfile(Worker)).read_bytes()).hexdigest() == expected
    assert not getattr(Worker.compile_or_warm_up_model, "_mxwave_rounding", False)
    original = Worker.compile_or_warm_up_model

    @functools.wraps(original)
    def prepared(worker, *args, **kwargs):
        result = original(worker, *args, **kwargs)
        report = worker.mxwave_prepare_dispatch_startup()
        assert worker.model_runner.vllm_config.speculative_config is None
        path = Path("/traces") / f"trial-startup-r{report['rank']}.json"
        path.write_text(json.dumps(report, indent=2) + "\n")
        return result

    prepared._mxwave_rounding = True
    Worker.compile_or_warm_up_model = prepared

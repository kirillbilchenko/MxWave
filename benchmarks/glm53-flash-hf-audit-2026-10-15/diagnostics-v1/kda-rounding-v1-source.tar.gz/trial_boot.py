"""Install the diagnostic entry point only in a disposable engine."""

from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile


def main():
    source = pathlib.Path(os.environ["MXWAVE_TRIAL_FROZEN_CODE"]) / "engine_plugin"
    with tempfile.TemporaryDirectory(prefix="mxwave-rounding-") as tmp:
        package = pathlib.Path(tmp) / "package"
        shutil.copytree(source, package)
        path = package / "pyproject.toml"
        text = path.read_text()
        assert text.count("[tool.setuptools]") == 1
        path.write_text(text.replace(
            "[tool.setuptools]",
            'mxwave_kda_rounding = "trial_plugin:install"\n\n[tool.setuptools]',
        ))
        subprocess.run([
            "uv", "pip", "install", "--python", "/usr/bin/python3",
            "--break-system-packages", "--no-deps", "--no-build-isolation", str(package),
        ], check=True)
    if os.environ.get("MXWAVE_VALIDATE_ONLY") == "1":
        from vllm import platforms
        from vllm.platforms.cpu import CpuPlatform
        platforms.current_platform = CpuPlatform()
        from vllm.entrypoints.cli.serve import cmd_init
        from vllm.plugins import load_general_plugins
        from vllm.utils.argparse_utils import FlexibleArgumentParser
        load_general_plugins()
        parser = FlexibleArgumentParser()
        sub = parser.add_subparsers(dest="subparser")
        commands = cmd_init()
        for command in commands:
            command.subparser_init(sub)
        args = parser.parse_args(sys.argv[1:])
        next(c for c in commands if c.name == args.subparser).validate(args)
        assert args.speculative_config is None
        assert args.max_logprobs == 154880
        import kda_rounding_worker
        assert hasattr(kda_rounding_worker.KdaRoundingWorker, "mxwave_rounding_initialize")
        import numpy as np
        import torch
        from kda_mxfp8_roundtrip import numpy_reference, roundtrip
        source = torch.linspace(-2, 3, 1024).reshape(8, 128).bfloat16()
        for actual, expected in zip(roundtrip(source), numpy_reference(source.float().numpy()), strict=True):
            np.testing.assert_array_equal(actual.numpy(), expected)
        print(json.dumps({"status": "validated", "speculation": False, "codec_reference": "exact"}))
        return
    key = pathlib.Path("/run/secrets/llm_api_key").read_text().strip()
    assert key and "\n" not in key
    os.environ["VLLM_API_KEY"] = key
    os.execv("/usr/bin/python3", [
        "/usr/bin/python3", "-c", "from vllm.entrypoints.cli.main import main; main()", *sys.argv[1:],
    ])


if __name__ == "__main__":
    main()
